import SwiftUI
import Foundation
import Security

@MainActor
final class LicenseManager: ObservableObject {
    enum State: Equatable {
        case loading
        case needsKey
        case validating
        case validated
        case failed(String)
    }

    @Published private(set) var state: State = .loading
    @Published var apiKey = ""

    private let service = "com.apple.mobile.MobileHouseArrest.external-injector-license"
    private let account = "kyojinx-api-key"
    // Configuração portada do projeto funcional enviado pelo usuário.
    private let bundledToken = "umDw4hMhR3oQc9MpAAj2SMP5NQJOkQfucHhJXx5jcvB5lcC3IyXUzOOOLi9rU4VPheHUVjXuIuoXFQUgcMK60zuhVY0VgQPa7u1vjdNyvI8MJpxRX"
    private var validationTimeout: DispatchWorkItem?

    var isValidated: Bool {
        if case .validated = state { return true }
        return false
    }

    init() {
        // O projeto de referência valida automaticamente com esta configuração.
        apiKey = bundledToken
        validate(bundledToken)
    }

    func submitKey() {
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else {
            state = .failed("Digite a API key para continuar.")
            return
        }
        storeKey(key)
        validate(key)
    }

    func clearKey() {
        deleteKey()
        apiKey = ""
        state = .needsKey
    }

    private func validate(_ key: String) {
        validationTimeout?.cancel()
        state = .validating

        let client = APIClient.shared()
        client.bwstMpltptacKBHkzURj12VuaeHziLlfbqWgi(key)
        client.ufN9gRM8reKhfRpqmE24j2wxcR("1.0.0")
        client.xYLnD1u5HhLSOAVXoebalBTQnPxg1S7oNhbyPpvnANaZAfmtX("com.apple.bundle")

        let timeout = DispatchWorkItem { [weak self] in
            Task { @MainActor in
                guard let self, case .validating = self.state else { return }
                self.state = .failed("Não foi possível validar a API key. Verifique a chave e tente novamente.")
            }
        }
        validationTimeout = timeout
        DispatchQueue.main.asyncAfter(deadline: .now() + 20, execute: timeout)

        _kx_run_paid_cb(nil) { [weak self] in
            Task { @MainActor in
                guard let self else { return }
                self.validationTimeout?.cancel()
                self.state = .validated
            }
        }
    }

    private func loadKey() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func storeKey(_ value: String) {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        if SecItemUpdate(query as CFDictionary, attributes as CFDictionary) != errSecSuccess {
            var item = query
            attributes.forEach { item[$0.key] = $0.value }
            _ = SecItemAdd(item as CFDictionary, nil)
        }
    }

    private func deleteKey() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        _ = SecItemDelete(query as CFDictionary)
    }
}

struct LicenseGateView: View {
    @EnvironmentObject private var licenseManager: LicenseManager
    @State private var showingKey = false

    var body: some View {
        ZStack {
            AppTheme.pageBackground.ignoresSafeArea()
            VStack(spacing: 24) {
                AppLogo(size: 92)
                VStack(spacing: 8) {
                    Text(Branding.appName)
                        .font(.largeTitle.bold())
                    Text("Digite sua API key para liberar o aplicativo.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }

                SecureField("API key", text: $licenseManager.apiKey)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(.horizontal, 16)
                    .frame(height: 52)
                    .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(AppTheme.accent.opacity(0.4)))

                Button {
                    licenseManager.submitKey()
                } label: {
                    Group {
                        if case .validating = licenseManager.state {
                            ProgressView().tint(.white)
                        } else {
                            Text("Continuar")
                        }
                    }
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                }
                .buttonStyle(.borderedProminent)
                .disabled(isBusy)

                if case let .failed(message) = licenseManager.state {
                    Text(message)
                        .font(.footnote)
                        .foregroundStyle(.red)
                        .multilineTextAlignment(.center)
                }
            }
            .padding(28)
            .frame(maxWidth: 520)
        }
        .interactiveDismissDisabled()
    }

    private var isBusy: Bool {
        if case .validating = licenseManager.state { return true }
        return false
    }
}
