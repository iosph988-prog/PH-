import SwiftUI
import UIKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @State private var tabNavigation: AppTabNavigationState

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-files-tab") {
            initialTab = 2
        } else if arguments.contains("--simulate-patch-tab") {
            initialTab = 1
        } else if arguments.contains("--simulate-cleaner-tab") {
            initialTab = 3
        } else if arguments.contains("--simulate-wallpaper-tab") {
            initialTab = 4
        } else {
            initialTab = 0
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        Group {
            if horizontalSizeClass == .regular {
                regularLayout
            } else {
                compactLayout
            }
        }
        .appTint()
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
        .background(AppTheme.pageBackground.ignoresSafeArea())
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                Section {
                    HStack(spacing: 12) {
                        AppLogo(size: 40)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(Branding.appName)
                                .font(.headline.weight(.semibold))
                            Text(language.text("dashboard.tagline"))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(2)
                        }
                    }
                    .padding(.vertical, 6)
                }

                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .foregroundStyle(
                                section.rawValue == tabNavigation.selectedTab
                                    ? AppTheme.accent
                                    : Color.primary
                            )
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(
                                section.rawValue == tabNavigation.selectedTab
                                    ? AppTheme.accent.opacity(0.12)
                                    : Color.clear
                            )
                            .padding(.horizontal, 8)
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .listStyle(.sidebar)
            .appScreenBackground()
            .navigationTitle(Branding.appName)
            .navigationSplitViewColumnWidth(min: 210, ideal: 248, max: 320)
        } detail: {
            sectionContent(AppSection(rawValue: tabNavigation.selectedTab) ?? .home)
                .id(tabNavigation.selectedTab)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            DashboardView()
        case .files:
            AppDataBrowserView(
                tabSession: filesTabSession
            )
        case .patches:
            PatchProjectsView()
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(cleanerEnabled: false, wallpapersEnabled: false)
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .files: return "tab.files"
        case .patches: return "tab.patches"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.circle.fill"
        case .files: return "slider.horizontal.3"
        case .patches: return "syringe.fill"
        }
    }
}

private struct DashboardView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showLogs = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    heroCard
                    metricsRow
                    installationCard
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
                .padding(.bottom, 28)
            }
            .appScreenBackground()
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text(Branding.appName)
                        .font(.headline.weight(.semibold))
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showLogs = true } label: {
                        Image(systemName: "apple.terminal")
                    }
                    .accessibilityLabel(language.text("accessibility.open_logs"))
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showSettings = true } label: {
                        Image(systemName: "gearshape.fill")
                    }
                    .accessibilityLabel(language.text("accessibility.open_settings"))
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showLogs) { LogView() }
        }
    }

    private var heroCard: some View {
        ZStack(alignment: .topTrailing) {
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [AppTheme.heroStart, AppTheme.heroEnd],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            Circle()
                .fill(.white.opacity(0.10))
                .frame(width: 180, height: 180)
                .offset(x: 54, y: -70)
            Circle()
                .fill(.white.opacity(0.06))
                .frame(width: 120, height: 120)
                .offset(x: -80, y: 90)

            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .center, spacing: 14) {
                    AppLogo(size: 54)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(Branding.appName)
                            .font(.title2.weight(.bold))
                            .foregroundStyle(.white)
                        Text(language.text("common.version", AppInfo.releaseVersion))
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(.white.opacity(0.78))
                    }
                    Spacer(minLength: 8)
                    compatibilityBadge
                }

                Text(language.text("dashboard.tagline"))
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.white.opacity(0.88))
                    .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 8) {
                    Image(systemName: "iphone")
                        .font(.caption.weight(.semibold))
                    Text(AppInfo.hardwareDisplayName)
                        .lineLimit(1)
                    Text("·")
                    Text("iOS \(AppInfo.osVersion)")
                        .lineLimit(1)
                }
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.82))
            }
            .padding(22)
        }
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .shadow(color: AppTheme.accentDeep.opacity(0.28), radius: 22, y: 10)
    }

    private var compatibilityBadge: some View {
        Text(language.text(appState.isSupported ? "dashboard.ready" : "settings.unsupported"))
            .font(.caption.weight(.bold))
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .foregroundStyle(.white)
            .background(.white.opacity(0.18), in: Capsule(style: .continuous))
            .overlay(
                Capsule(style: .continuous)
                    .stroke(.white.opacity(0.28), lineWidth: 1)
            )
    }

    private var metricsRow: some View {
        HStack(spacing: 12) {
            metricCard(
                title: language.text("dashboard.hardware_model"),
                value: AppInfo.displayMachineName,
                systemImage: "cpu"
            )
            metricCard(
                title: language.text("settings.ios_version"),
                value: "\(AppInfo.osVersion)\n(\(AppInfo.osBuild))",
                systemImage: "gear"
            )
        }
    }

    private func metricCard(title: String, value: String, systemImage: String) -> some View {
        AppCard(padding: 16) {
            VStack(alignment: .leading, spacing: 12) {
                AppRowIcon(systemName: systemImage)
                Text(title)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                Text(value)
                    .font(.system(.subheadline, design: .monospaced).weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(3)
                    .minimumScaleFactor(0.8)
            }
        }
    }

    /* private var featuresCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            AppSectionTitle(
                title: language.text("dashboard.features"),
                subtitle: language.text("dashboard.features_footer")
            )
            AppCard(padding: 6) {
                VStack(spacing: 0) {
                    featureToggle(
                        title: language.text("tab.cleaner"),
                        subtitle: language.text("cleaner.limited_mode"),
                        systemImage: "sparkles",
                        isOn: $cleanerEnabled
                    )
                    Divider().padding(.leading, 62)
                    featureToggle(
                        title: language.text("tab.wallpapers"),
                        subtitle: language.text("wallpaper.title"),
                        systemImage: "photo.on.rectangle.angled.fill",
                        isOn: $wallpapersEnabled
                    )
                }
            }
        }
    }

    */

    private func featureToggle(
        title: String,
        subtitle: String,
        systemImage: String,
        isOn: Binding<Bool>
    ) -> some View {
        Toggle(isOn: isOn) {
            HStack(spacing: 12) {
                AppRowIcon(systemName: systemImage)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.body.weight(.semibold))
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.vertical, 10)
            .padding(.horizontal, 10)
        }
        .tint(AppTheme.accent)
        .padding(.trailing, 10)
    }

    private var installationCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            AppSectionTitle(title: language.text("dashboard.installation"))
            AppCard {
                HStack(alignment: .top, spacing: 12) {
                    AppRowIcon(systemName: "checkmark.seal.fill")
                    VStack(alignment: .leading, spacing: 8) {
                        Text(language.text("dashboard.enterprise_signing"))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text(language.text("settings.supported_range_summary"))
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                }
            }
        }
    }
}
