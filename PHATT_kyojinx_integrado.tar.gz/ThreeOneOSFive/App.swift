import SwiftUI

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @StateObject private var licenseManager = LicenseManager()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var integrityOK = IntegrityGuard.validate()

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    var body: some Scene {
        WindowGroup {
            Group {
                if !integrityOK {
                    IntegrityFailureView()
                } else if licenseManager.isValidated {
                    ContentView()
                        .environmentObject(appState)
                        .environmentObject(patchDraftCoordinator)
                        .environmentObject(fileOperationCoordinator)
                        .environment(\.appLanguage, language)
                        .environment(\.locale, language.locale)
                        .tint(AppTheme.accent)
                        .onAppear {
                            AppTheme.configureSystemChrome()
                            appState.detectSupport()
                        }
                        .onOpenURL { url in
                            patchDraftCoordinator.presentImport(url)
                        }
                } else {
                    LicenseGateView()
                        .environmentObject(licenseManager)
                        .tint(AppTheme.accent)
                }
            }
        }
    }
}

enum Branding {
    static let appName: String = {
        let bytes: [UInt8] = [64, 80, 72, 32, 88, 73, 84, 69, 82]
        return String(decoding: bytes, as: UTF8.self)
    }()
}

enum IntegrityGuard {
    static func validate() -> Bool {
        guard let bundle = Bundle.main.bundleIdentifier,
              bundle == "com.apple.mobile.MobileHouseArrest",
              let displayName = bundleInfo("CFBundleDisplayName"),
              displayName == Branding.appName,
              let version = bundleInfo("CFBundleShortVersionString"),
              version == "1.0.1",
              let executable = Bundle.main.executableURL,
              FileManager.default.isReadableFile(atPath: executable.path)
        else { return false }
        return true
    }

    private static func bundleInfo(_ key: String) -> String? {
        Bundle.main.object(forInfoDictionaryKey: key) as? String
    }
}

private struct IntegrityFailureView: View {
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "checkmark.shield.fill")
                .font(.system(size: 46))
            Text("Verificação de integridade falhou")
                .font(.headline)
            Text("Esta cópia foi alterada ou não está assinada corretamente.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
        }
        .padding(32)
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
        }
    }
}
