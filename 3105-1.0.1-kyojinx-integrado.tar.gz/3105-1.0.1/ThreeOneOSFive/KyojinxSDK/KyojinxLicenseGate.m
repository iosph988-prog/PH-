#import "KyojinxLicenseGate.h"
#import "APIClient.h"

static NSString * const KyojinxLicenseErrorDomain = @"KyojinxLicenseGate";
static NSTimeInterval const KyojinxLicenseTimeout = 15.0;

@interface KyojinxLicenseGate ()
@property (nonatomic, readwrite) KyojinxLicenseState state;
@property (nonatomic, assign) BOOL completionDelivered;
@end

@implementation KyojinxLicenseGate

- (instancetype)init {
    self = [super init];
    if (self) {
        _state = KyojinxLicenseStateNotConfigured;
    }
    return self;
}

- (void)validateWithCompletion:(KyojinxLicenseCompletion)completion {
    NSParameterAssert(completion != nil);

    NSString *token = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"KyojinxLicenseToken"];
    NSString *version = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"KyojinxLicenseVersion"] ?: @"1.0.0";
    NSString *product = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"KyojinxLicenseProduct"] ?: @"com.apple.bundle";

    if (![token isKindOfClass:NSString.class] || token.length == 0 || [token hasPrefix:@"$("]) {
        self.state = KyojinxLicenseStateNotConfigured;
        NSError *error = [NSError errorWithDomain:KyojinxLicenseErrorDomain
                                               code:1
                                           userInfo:@{NSLocalizedDescriptionKey: @"KyojinxLicenseToken não foi configurado no target."}];
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(NO, error);
        });
        return;
    }

    self.state = KyojinxLicenseStateChecking;
    self.completionDelivered = NO;

    APIClient *api = [APIClient sharedAPIClient];
    [api BwstMpltptacKBHkzURj12VuaeHziLlfbqWgi:token];
    [api ufN9gRM8reKhfRpqmE24j2wxcR:version];
    [api xYLnD1u5HhLSOAVXoebalBTQnPxg1S7oNhbyPpvnANaZAfmtX:product];

    __weak typeof(self) weakSelf = self;
    void (^finish)(BOOL, NSError *) = ^(BOOL valid, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) self = weakSelf;
            if (!self || self.completionDelivered) return;
            self.completionDelivered = YES;
            self.state = valid ? KyojinxLicenseStateValidated : KyojinxLicenseStateFailed;
            completion(valid, error);
        });
    };

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(KyojinxLicenseTimeout * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        NSError *error = [NSError errorWithDomain:KyojinxLicenseErrorDomain
                                               code:2
                                           userInfo:@{NSLocalizedDescriptionKey: @"A validação Kyojinx expirou sem retorno do SDK."}];
        finish(NO, error);
    });

    _kx_run_paid_cb(api, ^{
        finish(YES, nil);
    });
}

@end
