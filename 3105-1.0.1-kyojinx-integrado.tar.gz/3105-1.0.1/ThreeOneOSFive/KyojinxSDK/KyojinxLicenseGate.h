#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, KyojinxLicenseState) {
    KyojinxLicenseStateNotConfigured = 0,
    KyojinxLicenseStateChecking,
    KyojinxLicenseStateValidated,
    KyojinxLicenseStateFailed,
};

typedef void (^KyojinxLicenseCompletion)(BOOL valid, NSError * _Nullable error);

@interface KyojinxLicenseGate : NSObject

@property (nonatomic, readonly) KyojinxLicenseState state;

- (void)validateWithCompletion:(KyojinxLicenseCompletion)completion;

@end

NS_ASSUME_NONNULL_END
