import SwiftUI
import UIKit

enum AppTheme {
    static let accent = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.45, green: 0.70, blue: 1.00, alpha: 1.00)
                : UIColor(red: 0.11, green: 0.42, blue: 0.98, alpha: 1.00)
        }
    )
    static let accentDeep = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.18, green: 0.38, blue: 0.78, alpha: 1.00)
                : UIColor(red: 0.05, green: 0.24, blue: 0.62, alpha: 1.00)
        }
    )
    static let pageBackground = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.04, green: 0.07, blue: 0.13, alpha: 1.00)
                : UIColor(red: 0.94, green: 0.96, blue: 0.99, alpha: 1.00)
        }
    )
    static let cardBackground = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.08, green: 0.12, blue: 0.20, alpha: 1.00)
                : UIColor.white
        }
    )
    static let barFill = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.06, green: 0.09, blue: 0.16, alpha: 0.94)
                : UIColor(red: 0.98, green: 0.99, blue: 1.00, alpha: 0.94)
        }
    )
    static let searchFill = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.12, green: 0.17, blue: 0.27, alpha: 1.00)
                : UIColor.white
        }
    )
    static let consoleBackground = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.05, green: 0.08, blue: 0.14, alpha: 1.00)
                : UIColor(red: 0.96, green: 0.97, blue: 0.99, alpha: 1.00)
        }
    )
    static let stroke = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.22, green: 0.32, blue: 0.48, alpha: 0.55)
                : UIColor(red: 0.75, green: 0.84, blue: 0.95, alpha: 0.90)
        }
    )
    static let cardShadow = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor.black.withAlphaComponent(0.35)
                : UIColor(red: 0.15, green: 0.32, blue: 0.62, alpha: 0.10)
        }
    )
    static let heroStart = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.07, green: 0.16, blue: 0.34, alpha: 1.00)
                : UIColor(red: 0.07, green: 0.24, blue: 0.62, alpha: 1.00)
        }
    )
    static let heroEnd = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.14, green: 0.38, blue: 0.78, alpha: 1.00)
                : UIColor(red: 0.20, green: 0.56, blue: 1.00, alpha: 1.00)
        }
    )
    static let success = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.42, green: 0.86, blue: 0.68, alpha: 1.00)
                : UIColor(red: 0.07, green: 0.62, blue: 0.47, alpha: 1.00)
        }
    )
    static let warning = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 1.00, green: 0.78, blue: 0.38, alpha: 1.00)
                : UIColor(red: 0.86, green: 0.52, blue: 0.08, alpha: 1.00)
        }
    )

    static let pageInset: CGFloat = 16
    static let cardRadius: CGFloat = 22
    static let controlRadius: CGFloat = 14
    static let rowIconSize: CGFloat = 16
    static let rowIconFrame: CGFloat = 34
    static let fileRowIconSize: CGFloat = 16
    static let fileRowIconFrame: CGFloat = 34
    static let fileRowHeight: CGFloat = 62
    static let appIconSize: CGFloat = 36
    static let emptyIconSize: CGFloat = 28
    static let selectionIconSize: CGFloat = 20

    static func configureSystemChrome() {
        let accentColor = UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.45, green: 0.70, blue: 1.00, alpha: 1.00)
                : UIColor(red: 0.11, green: 0.42, blue: 0.98, alpha: 1.00)
        }
        let barColor = UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.06, green: 0.09, blue: 0.16, alpha: 1.00)
                : UIColor(red: 0.98, green: 0.99, blue: 1.00, alpha: 1.00)
        }

        UIView.appearance().tintColor = accentColor

        let navigation = UINavigationBarAppearance()
        navigation.configureWithOpaqueBackground()
        navigation.backgroundColor = barColor
        navigation.shadowColor = UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor.white.withAlphaComponent(0.06)
                : UIColor(red: 0.75, green: 0.84, blue: 0.95, alpha: 0.80)
        }
        navigation.titleTextAttributes = [
            .foregroundColor: UIColor.label,
            .font: UIFont.systemFont(ofSize: 17, weight: .semibold)
        ]
        navigation.largeTitleTextAttributes = [
            .foregroundColor: UIColor.label,
            .font: UIFont.systemFont(ofSize: 34, weight: .bold)
        ]
        UINavigationBar.appearance().standardAppearance = navigation
        UINavigationBar.appearance().scrollEdgeAppearance = navigation
        UINavigationBar.appearance().compactAppearance = navigation
        UINavigationBar.appearance().tintColor = accentColor
        UINavigationBar.appearance().isTranslucent = false

        let tab = UITabBarAppearance()
        tab.configureWithOpaqueBackground()
        tab.backgroundColor = barColor
        tab.shadowColor = navigation.shadowColor
        UITabBar.appearance().standardAppearance = tab
        UITabBar.appearance().scrollEdgeAppearance = tab
        UITabBar.appearance().tintColor = accentColor
        UITabBar.appearance().unselectedItemTintColor = UIColor.secondaryLabel
        UITabBar.appearance().isTranslucent = false

        UISwitch.appearance().onTintColor = accentColor
        UIProgressView.appearance().tintColor = accentColor
    }
}

struct AppRowIcon: View {
    let systemName: String
    var tint: Color = AppTheme.accent
    var symbolSize: CGFloat = AppTheme.rowIconSize
    var frameSize: CGFloat = AppTheme.rowIconFrame

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [tint.opacity(0.18), tint.opacity(0.08)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            Image(systemName: systemName)
                .font(.system(size: symbolSize, weight: .semibold))
                .foregroundStyle(tint)
        }
        .frame(width: frameSize, height: frameSize)
        .overlay(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .stroke(tint.opacity(0.12), lineWidth: 1)
        )
        .accessibilityHidden(true)
    }
}

struct AppSearchField: View {
    @Binding var text: String
    let prompt: String
    let clearLabel: String

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(text.isEmpty ? Color.secondary : AppTheme.accent)
                .accessibilityHidden(true)

            TextField(prompt, text: $text)
                .font(.body)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(clearLabel)
            }
        }
        .padding(.horizontal, 14)
        .frame(minHeight: 42)
        .background(AppTheme.searchFill, in: Capsule(style: .continuous))
        .overlay(
            Capsule(style: .continuous)
                .stroke(AppTheme.stroke, lineWidth: 1)
        )
        .padding(.horizontal, AppTheme.pageInset)
        .padding(.vertical, 10)
        .background(AppTheme.pageBackground)
    }
}

struct AppLogo: View {
    var size: CGFloat = 48

    var body: some View {
        Group {
            if let icon = UIImage(named: "AppIcon60x60")
                ?? Bundle.main.path(forResource: "AppIcon60x60@2x", ofType: "png").flatMap(UIImage.init(contentsOfFile:))
                ?? UIImage(named: "AppIcon") {
                Image(uiImage: icon)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "square.stack.3d.up.fill")
                    .font(.system(size: size * 0.42, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(
                        LinearGradient(
                            colors: [AppTheme.heroStart, AppTheme.heroEnd],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
                .stroke(.white.opacity(0.28), lineWidth: 1)
        )
        .shadow(color: AppTheme.accent.opacity(0.28), radius: 10, y: 4)
        .accessibilityHidden(true)
    }
}

struct AppCard<Content: View>: View {
    var padding: CGFloat = 18
    @ViewBuilder var content: () -> Content

    var body: some View {
        content()
            .padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: AppTheme.cardRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: AppTheme.cardRadius, style: .continuous)
                    .stroke(AppTheme.stroke, lineWidth: 1)
            )
            .shadow(color: AppTheme.cardShadow, radius: 18, y: 8)
    }
}

struct AppSectionTitle: View {
    let title: String
    var subtitle: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.title3.weight(.semibold))
                .foregroundStyle(.primary)
            if let subtitle, !subtitle.isEmpty {
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct AppStatusPill: View {
    let title: String
    var systemImage: String
    var isPositive: Bool

    var body: some View {
        Label(title, systemImage: systemImage)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .foregroundStyle(isPositive ? AppTheme.success : AppTheme.warning)
            .background(
                (isPositive ? AppTheme.success : AppTheme.warning).opacity(0.14),
                in: Capsule(style: .continuous)
            )
    }
}

struct AppEmptyState: View {
    let systemName: String
    let title: String
    var message: String?
    var actionTitle: String?
    var action: (() -> Void)?

    var body: some View {
        VStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [AppTheme.accent.opacity(0.16), AppTheme.accent.opacity(0.06)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 84, height: 84)
                Image(systemName: systemName)
                    .font(.system(size: AppTheme.emptyIconSize, weight: .semibold))
                    .foregroundStyle(AppTheme.accent)
            }

            Text(title)
                .font(.title3.weight(.semibold))
                .multilineTextAlignment(.center)

            if let message {
                Text(message)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }

            if let actionTitle, let action {
                Button(actionTitle, action: action)
                    .buttonStyle(.borderedProminent)
                    .buttonBorderShape(.roundedRectangle(radius: AppTheme.controlRadius))
                    .controlSize(.large)
                    .padding(.top, 4)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 28)
        .padding(.vertical, 36)
    }
}

struct PremiumButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled
    var isDestructive = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.body.weight(.semibold))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity, minHeight: 50)
            .background(
                RoundedRectangle(cornerRadius: AppTheme.controlRadius, style: .continuous)
                    .fill(isDestructive ? Color.red : AppTheme.accent)
            )
            .opacity(isEnabled ? (configuration.isPressed ? 0.86 : 1) : 0.42)
    }
}

extension View {
    func appScreenBackground() -> some View {
        scrollContentBackground(.hidden)
            .background(AppTheme.pageBackground.ignoresSafeArea())
    }

    func appTint() -> some View {
        tint(AppTheme.accent)
    }
}
