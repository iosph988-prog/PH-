# License Atelier — Visual Store

Esta é uma variante **visual-only** do projeto. Ela contém uma galeria SwiftUI com filtro por Free Fire e Free Fire MAX, inclui os arquivos `.3105` como recursos locais do bundle para inspeção visual/organização e pode consultar o catálogo remoto do License Atelier.

A variante não contém aplicação de patches, acesso a contêineres de outros aplicativos, injeção, exploit, escape de sandbox ou anti-detecção. A consulta remota usa apenas `POST /api/patches/catalog` para ler metadados publicados; ela não chama `/api/patches/download`, não baixa arquivos e não altera nenhum jogo ou aplicativo instalado.

## Compilação no macOS

Instale o Xcode e o XcodeGen. Na raiz deste projeto, execute:

```bash
brew install xcodegen
xcodegen generate
open VisualStore.xcodeproj
```

Depois, selecione um simulador ou dispositivo próprio no Xcode e use **Run**. Para gerar um arquivo IPA assinado, configure a equipe de desenvolvimento e o identificador de bundle no Xcode; a assinatura depende da conta Apple do proprietário do aplicativo.

## Integração remota segura

O endpoint público configurado é `https://keypanel-mefhz8pp.manus.space/api/patches/catalog`. O app envia a chave informada pelo usuário, um identificador local do dispositivo, o Bundle ID correspondente ao jogo selecionado e a versão do app. Quando a licença ou a rede falham, a interface retorna automaticamente ao catálogo local.

## Recursos incluídos

Os recursos `.3105` são tratados apenas como arquivos locais do bundle. A interface mostra nomes, grupos de jogo e tamanhos representativos para navegação visual. Nenhum recurso é aplicado a outro processo ou aplicativo.
