import Foundation

struct RemotePatch: Decodable, Identifiable {
    let id: Int
    let slug: String
    let title: String
    let game: String
    let enabled: Bool
    let injectionMode: String?
    let bundleId: String?
    let injectionPath: String?
    let originalSearchName: String?
    let versionId: Int
    let version: Int
    let fileName: String
    let sha256: String
    let sizeBytes: Int
    let downloadUrl: String?

    var displayGame: String {
        game == "free-fire-max" ? "Free Fire MAX" : "Free Fire"
    }
}

struct RemoteCatalogResponse: Decodable {
    let valid: Bool
    let code: String?
    let message: String?
    let patches: [RemotePatch]?
}

struct RemoteCatalogClient {
    let endpoint = URL(string: "https://keypanel-mefhz8pp.manus.space/api/patches/catalog")!

    func fetchCatalog(licenseKey: String, deviceId: String, packageName: String, appVersion: String) async throws -> RemoteCatalogResponse {
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 12
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode([
            "key": licenseKey,
            "device_id": deviceId,
            "package": packageName,
            "app_version": appVersion
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse,
              (200..<500).contains(httpResponse.statusCode) else {
            throw URLError(.badServerResponse)
        }
        let decoded = try JSONDecoder().decode(RemoteCatalogResponse.self, from: data)
        guard decoded.valid else {
            throw RemoteCatalogError.rejected(decoded.message ?? decoded.code ?? "A licença não foi aceita")
        }
        return decoded
    }
}

enum RemoteCatalogError: LocalizedError {
    case rejected(String)

    var errorDescription: String? {
        switch self {
        case .rejected(let message): return message
        }
    }
}
