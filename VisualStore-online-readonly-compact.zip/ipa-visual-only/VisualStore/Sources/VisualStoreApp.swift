import SwiftUI
import Combine

@main
struct VisualStoreApp: App {
    var body: some Scene {
        WindowGroup {
            CatalogView()
        }
    }
}

struct VisualAsset: Identifiable {
    let id: String
    let name: String
    let game: String
    let size: String
    let color: Color
    let isRemote: Bool
}

@MainActor
final class RemoteCatalogViewModel: ObservableObject {
    @Published private(set) var remotePatches: [RemotePatch] = []
    @Published private(set) var isLoading = false
    @Published private(set) var status = "Catálogo local pronto"
    @Published private(set) var lastError: String?

    private let client = RemoteCatalogClient()
    private let deviceIdKey = "visualstore.device.id"

    var deviceId: String {
        if let stored = UserDefaults.standard.string(forKey: deviceIdKey) {
            return stored
        }
        let created = UUID().uuidString
        UserDefaults.standard.set(created, forKey: deviceIdKey)
        return created
    }

    func refresh(licenseKey: String, game: String) async {
        let trimmedKey = licenseKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedKey.isEmpty else {
            remotePatches = []
            lastError = "Informe sua chave de licença para consultar o catálogo remoto."
            status = "Exibindo catálogo local"
            return
        }

        isLoading = true
        lastError = nil
        defer { isLoading = false }

        do {
            let games = game == "Todos" ? ["Free Fire", "Free Fire MAX"] : [game]
            var combined: [RemotePatch] = []
            for selected in games {
                let response = try await client.fetchCatalog(
                    licenseKey: trimmedKey,
                    deviceId: deviceId,
                    packageName: selected == "Free Fire MAX" ? "com.dts.freefiremax" : "com.dts.freefireth",
                    appVersion: Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
                )
                combined.append(contentsOf: response.patches ?? [])
            }
            remotePatches = combined
            status = remotePatches.isEmpty ? "API conectada; nenhum item remoto disponível" : "Catálogo remoto sincronizado"
        } catch {
            remotePatches = []
            lastError = error.localizedDescription
            status = "Offline ou sem autorização; usando catálogo local"
        }
    }
}

@MainActor
struct CatalogView: View {
    private let localAssets: [VisualAsset] = [
        .init(id: "local-hs-peito", name: "HS PEITO BRUTO", game: "Free Fire", size: "64 KB", color: .pink, isRemote: false),
        .init(id: "local-hs-barriga", name: "HS BARRIGA + ANTENA", game: "Free Fire", size: "47 KB", color: .orange, isRemote: false),
        .init(id: "local-holograma-3d", name: "HOLOGRAMA 3D", game: "Free Fire MAX", size: "1.4 MB", color: .purple, isRemote: false),
        .init(id: "local-holograma-verde", name: "HOLOGRAMA VERDE 3D", game: "Free Fire MAX", size: "4.7 MB", color: .green, isRemote: false),
        .init(id: "local-holograma-vermelho", name: "HOLOGRAMA VERMELHO 3D", game: "Free Fire MAX", size: "12.5 MB", color: .red, isRemote: false),
        .init(id: "local-pescoco-cache", name: "PESCOÇO LI-TE + CACHE", game: "Free Fire", size: "47 KB", color: .blue, isRemote: false),
        .init(id: "local-120fps", name: "120 FPS", game: "Free Fire MAX", size: "140 KB", color: .cyan, isRemote: false),
        .init(id: "local-magic", name: "MAGIC", game: "Free Fire", size: "64 KB", color: .indigo, isRemote: false)
    ]

    @AppStorage("visualstore.license.key") private var licenseKey = ""
    @StateObject private var model = RemoteCatalogViewModel()
    @State private var selectedGame = "Todos"
    @State private var searchText = ""

    private var visibleAssets: [VisualAsset] {
        let remote = model.remotePatches.map { patch in
            VisualAsset(
                id: "remote-\(patch.id)-\(patch.versionId)",
                name: patch.title,
                game: patch.displayGame,
                size: ByteCountFormatter.string(fromByteCount: Int64(patch.sizeBytes), countStyle: .file),
                color: color(for: patch.game),
                isRemote: true
            )
        }
        return remote.isEmpty ? localAssets : remote
    }

    private var filteredAssets: [VisualAsset] {
        visibleAssets.filter { asset in
            (selectedGame == "Todos" || asset.game == selectedGame) &&
            (searchText.isEmpty || asset.name.localizedCaseInsensitiveContains(searchText))
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.04, green: 0.04, blue: 0.09).ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        header
                        licenseSection
                        Picker("Jogo", selection: $selectedGame) {
                            Text("Todos").tag("Todos")
                            Text("Free Fire").tag("Free Fire")
                            Text("Free Fire MAX").tag("Free Fire MAX")
                        }
                        .pickerStyle(.segmented)
                        .tint(.pink)

                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 160), spacing: 14)], spacing: 14) {
                            ForEach(filteredAssets) { asset in
                                AssetCard(asset: asset)
                            }
                        }
                    }
                    .padding(20)
                }
            }
            .searchable(text: $searchText, prompt: "Buscar visual")
            .navigationBarHidden(true)
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "sparkles.rectangle.stack.fill")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundStyle(.pink)
                Spacer()
                Text(model.remotePatches.isEmpty ? "LOCAL FALLBACK" : "ONLINE READ-ONLY")
                    .font(.caption.weight(.bold))
                    .tracking(1.5)
                    .foregroundStyle(model.remotePatches.isEmpty ? Color.secondary : Color.green)
            }
            Text("License Atelier")
                .font(.system(size: 34, weight: .bold, design: .rounded))
            Text("Catálogo visual remoto")
                .foregroundStyle(.secondary)
            Text("A API é usada somente para consultar metadados e estados publicados. Nenhum arquivo é baixado, aplicado ou enviado para outro aplicativo.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .padding(.top, 4)
        }
    }

    private var licenseSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Sincronização")
                .font(.headline)
            SecureField("Chave de licença", text: $licenseKey)
                .textFieldStyle(.roundedBorder)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            HStack(spacing: 10) {
                Button {
                    Task {
                        await model.refresh(licenseKey: licenseKey, game: selectedGame == "Free Fire MAX" ? "Free Fire MAX" : "Free Fire")
                    }
                } label: {
                    Label(model.isLoading ? "Consultando…" : "Atualizar catálogo", systemImage: "arrow.triangle.2.circlepath")
                }
                .buttonStyle(.borderedProminent)
                .disabled(model.isLoading)

                Text(model.status)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            if let lastError = model.lastError {
                Text(lastError)
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
        }
        .padding(14)
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
    }

    private func color(for game: String) -> Color {
        game == "free-fire-max" ? .purple : .pink
    }
}

@MainActor
struct AssetCard: View {
    let asset: VisualAsset
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            RoundedRectangle(cornerRadius: 18)
                .fill(asset.color.gradient)
                .frame(height: 92)
                .overlay {
                    Image(systemName: asset.isRemote ? "icloud.and.arrow.down" : "photo.fill")
                        .font(.system(size: 30))
                        .foregroundStyle(.white.opacity(0.9))
                }
            Text(asset.name)
                .font(.headline)
                .lineLimit(2)
            HStack {
                Text(asset.game)
                Spacer()
                Text(asset.size)
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .padding(12)
        .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
        .overlay {
            RoundedRectangle(cornerRadius: 18)
                .stroke(.white.opacity(0.08))
        }
    }
}
