import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Image(systemName: "checkmark.shield")
                    .font(.system(size: 54))
                    .foregroundStyle(.blue)
                Text("3105 Sanitized Build")
                    .font(.title2.weight(.semibold))
                Text("Interface segura para validação de compilação")
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationTitle("3105")
        }
    }
}
