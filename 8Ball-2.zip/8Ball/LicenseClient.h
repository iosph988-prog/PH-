#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LicenseClient : NSObject
+ (void)startWithPresenter:(UIViewController *)presenter
                onSuccess:(dispatch_block_t)onSuccess;
@end

NS_ASSUME_NONNULL_END
