#import "LicenseClient.h"
#import <Security/Security.h>

static NSString * const kLicenseEndpoint =
    @"https://api-production-182c.up.railway.app/api/license/validate";
static NSString * const kLicenseKeychainService = @"com.dkhoa.8ball.license";
static NSString * const kLicenseKeychainAccount = @"license-key";
static NSString * const kFallbackDeviceIDKey = @"com.dkhoa.8ball.device-id";

static NSDictionary *LicenseKeychainQuery(void) {
    return @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: kLicenseKeychainService,
        (__bridge id)kSecAttrAccount: kLicenseKeychainAccount
    };
}

static NSString *LoadSavedLicenseKey(void) {
    NSMutableDictionary *query = [LicenseKeychainQuery() mutableCopy];
    query[(__bridge id)kSecReturnData] = @YES;
    query[(__bridge id)kSecMatchLimit] = (__bridge id)kSecMatchLimitOne;

    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
    if (status != errSecSuccess || result == NULL) return nil;

    NSData *data = CFBridgingRelease(result);
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

static void SaveLicenseKey(NSString *key) {
    NSDictionary *query = LicenseKeychainQuery();
    SecItemDelete((__bridge CFDictionaryRef)query);

    NSData *data = [key dataUsingEncoding:NSUTF8StringEncoding];
    if (data.length == 0) return;

    NSMutableDictionary *item = [query mutableCopy];
    item[(__bridge id)kSecValueData] = data;
    item[(__bridge id)kSecAttrAccessible] = (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly;
    SecItemAdd((__bridge CFDictionaryRef)item, NULL);
}

static NSString *LicenseDeviceID(void) {
    NSString *vendorID = UIDevice.currentDevice.identifierForVendor.UUIDString;
    if (vendorID.length > 0) return vendorID;

    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    NSString *savedID = [defaults stringForKey:kFallbackDeviceIDKey];
    if (savedID.length > 0) return savedID;

    NSString *newID = NSUUID.UUID.UUIDString;
    [defaults setObject:newID forKey:kFallbackDeviceIDKey];
    [defaults synchronize];
    return newID;
}

static NSString *LicensePackageName(void) {
    NSString *bundleID = NSBundle.mainBundle.bundleIdentifier;
    return bundleID.length > 0 ? bundleID : @"com.miniclip.8ballpool";
}

static NSString *LicenseAppVersion(void) {
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    NSString *version = info[@"CFBundleShortVersionString"];
    if (![version isKindOfClass:NSString.class] || version.length == 0) {
        version = info[@"CFBundleVersion"];
    }
    return ([version isKindOfClass:NSString.class] && version.length > 0) ? version : @"unknown";
}

static NSDate *ParseLicenseExpiration(NSString *value) {
    NSISO8601DateFormatter *formatter = [[NSISO8601DateFormatter alloc] init];
    formatter.formatOptions = NSISO8601DateFormatWithInternetDateTime |
                              NSISO8601DateFormatWithFractionalSeconds;
    NSDate *date = [formatter dateFromString:value];
    if (date == nil) {
        formatter.formatOptions = NSISO8601DateFormatWithInternetDateTime;
        date = [formatter dateFromString:value];
    }
    return date;
}

static void ValidateLicenseKey(NSString *key,
                               void (^completion)(BOOL valid, NSString *message)) {
    NSURL *url = [NSURL URLWithString:kLicenseEndpoint];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url
                                                           cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                                       timeoutInterval:20.0];
    request.HTTPMethod = @"POST";
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];

    NSDictionary *body = @{
        @"key": key ?: @"",
        @"device_id": LicenseDeviceID(),
        @"package": LicensePackageName(),
        @"app_version": LicenseAppVersion()
    };

    NSError *serializationError = nil;
    request.HTTPBody = [NSJSONSerialization dataWithJSONObject:body
                                                       options:0
                                                         error:&serializationError];
    if (serializationError != nil || request.HTTPBody == nil) {
        completion(NO, @"Não foi possível preparar a validação da licença.");
        return;
    }

    NSURLSessionDataTask *task = [NSURLSession.sharedSession
        dataTaskWithRequest:request
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (error != nil) {
                    completion(NO, @"Falha de conexão com o servidor de licenças. Tente novamente.");
                    return;
                }

                NSHTTPURLResponse *http = (NSHTTPURLResponse *)response;
                NSDictionary *payload = nil;
                if (data.length > 0) {
                    id parsed = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                    if ([parsed isKindOfClass:NSDictionary.class]) payload = parsed;
                }

                NSString *serverMessage = [payload[@"message"] isKindOfClass:NSString.class]
                    ? payload[@"message"] : nil;
                NSNumber *validFlag = [payload[@"valid"] isKindOfClass:NSNumber.class]
                    ? payload[@"valid"] : nil;
                BOOL valid = http.statusCode >= 200 && http.statusCode < 300 &&
                             validFlag != nil && validFlag.boolValue;

                if (valid) {
                    id expirationValue = payload[@"expiresAt"];
                    if ([expirationValue isKindOfClass:NSString.class] &&
                        [(NSString *)expirationValue length] > 0) {
                        NSDate *expiration = ParseLicenseExpiration((NSString *)expirationValue);
                        if (expiration == nil) {
                            completion(NO, @"A API retornou uma data de expiração inválida.");
                            return;
                        }
                        if ([expiration timeIntervalSinceNow] <= 0) {
                            completion(NO, @"A licença está expirada.");
                            return;
                        }
                    }
                    SaveLicenseKey(key);
                    completion(YES, serverMessage.length > 0 ? serverMessage : @"Licença validada.");
                    return;
                }

                if (serverMessage.length > 0) {
                    completion(NO, serverMessage);
                } else if (http.statusCode > 0) {
                    completion(NO, [NSString stringWithFormat:@"Validação rejeitada (HTTP %ld).",
                                    (long)http.statusCode]);
                } else {
                    completion(NO, @"Resposta inválida do servidor de licenças.");
                }
            });
        }];
    [task resume];
}

static void PresentActivationPrompt(UIViewController *presenter,
                                    NSString *statusMessage,
                                    NSString *initialKey,
                                    dispatch_block_t onSuccess) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (presenter.presentedViewController != nil) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                PresentActivationPrompt(presenter, statusMessage, initialKey, onSuccess);
            });
            return;
        }

        NSString *message = statusMessage.length > 0
            ? statusMessage : @"Digite sua chave para validar o acesso.";
        UIAlertController *alert = [UIAlertController
            alertControllerWithTitle:@"FFH4X 8BALL"
                             message:message
                      preferredStyle:UIAlertControllerStyleAlert];

        [alert addTextFieldWithConfigurationHandler:^(UITextField *field) {
            field.placeholder = @"CHAVE-DE-LICENÇA";
            field.text = initialKey;
            field.secureTextEntry = YES;
            field.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
            field.autocorrectionType = UITextAutocorrectionTypeNo;
            field.spellCheckingType = UITextSpellCheckingTypeNo;
            field.clearButtonMode = UITextFieldViewModeWhileEditing;
        }];

        [alert addAction:[UIAlertAction actionWithTitle:@"Ativar"
                                                 style:UIAlertActionStyleDefault
                                               handler:^(__unused UIAlertAction *action) {
            NSString *key = [alert.textFields.firstObject.text
                stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
            if (key.length == 0) {
                PresentActivationPrompt(presenter, @"Digite uma chave de licença.", key, onSuccess);
                return;
            }

            ValidateLicenseKey(key, ^(BOOL valid, NSString *message) {
                if (valid) {
                    if (onSuccess) onSuccess();
                } else {
                    PresentActivationPrompt(presenter, message, key, onSuccess);
                }
            });
        }]];

        [alert addAction:[UIAlertAction actionWithTitle:@"Cancelar"
                                                 style:UIAlertActionStyleCancel
                                               handler:nil]];
        [presenter presentViewController:alert animated:YES completion:nil];
    });
}

@implementation LicenseClient

+ (void)startWithPresenter:(UIViewController *)presenter
                onSuccess:(dispatch_block_t)onSuccess {
    if (presenter == nil) return;

    NSString *savedKey = LoadSavedLicenseKey();
    if (savedKey.length == 0) {
        PresentActivationPrompt(presenter, nil, nil, onSuccess);
        return;
    }

    ValidateLicenseKey(savedKey, ^(BOOL valid, NSString *message) {
        if (valid) {
            if (onSuccess) onSuccess();
        } else {
            PresentActivationPrompt(presenter, message, savedKey, onSuccess);
        }
    });
}

@end
