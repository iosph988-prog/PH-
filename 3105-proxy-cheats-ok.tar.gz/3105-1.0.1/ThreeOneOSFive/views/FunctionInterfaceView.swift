import SwiftUI
import UIKit

struct FunctionInterfaceView: View {
    private enum Tab: String, CaseIterable {
        case function = "Function"
        case textures = "Texturas"
        case config = "Config"
    }

    struct FunctionItem: Identifiable {
        let id: String
        let title: String
        let bundledFile: String?
        let initialValue: Bool
    }

    private let items: [FunctionItem] = [
        FunctionItem(id: "pescoco", title: "Pescoço", bundledFile: "Pescoco.3105", initialValue: false),
        FunctionItem(id: "peito", title: "Peito", bundledFile: "Peito.3105", initialValue: false),
        FunctionItem(id: "magica", title: "Mágica", bundledFile: "AZUL-.3105", initialValue: false),
        FunctionItem(id: "municao", title: "Munição", bundledFile: "Wi-Fi.3105", initialValue: false),
        FunctionItem(id: "teste3d", title: "Teste 3D", bundledFile: nil, initialValue: false),
        FunctionItem(id: "teste-personagem", title: "Teste Personagem", bundledFile: nil, initialValue: false)
    ]

    @State private var selectedTab: Tab = .function
    @State private var selectedMode = "Max"
    @AppStorage("function.pescoco.enabled") private var pescocoEnabled = false
    @AppStorage("function.peito.enabled") private var peitoEnabled = false
    @AppStorage("function.magica.enabled") private var magicaEnabled = false
    @AppStorage("function.municao.enabled") private var municaoEnabled = false
    @AppStorage("function.teste3d.enabled") private var teste3DEnabled = false
    @AppStorage("function.teste-personagem.enabled") private var testePersonagemEnabled = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 0) {
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 14) {
                        header
                        modePicker

                        if selectedTab == .function {
                            functionList
                        } else if selectedTab == .textures {
                            placeholder(title: "Texturas", systemImage: "square.grid.2x2.fill")
                        } else {
                            placeholder(title: "Config", systemImage: "gearshape.fill")
                        }
                    }
                    .padding(.horizontal, 28)
                    .padding(.top, 26)
                    .padding(.bottom, 32)
                }

                bottomNavigation
                    .padding(.horizontal, 60)
                    .padding(.bottom, 22)
            }
        }
        .preferredColorScheme(.dark)
        .statusBarHidden(false)
    }

    private var header: some View {
        HStack {
            Text("PROXY CHEATS OK")
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(Color.white.opacity(0.62))
            Spacer()
        }
        .padding(.horizontal, 28)
        .frame(height: 108)
        .background(Color(red: 0.10, green: 0.10, blue: 0.11), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private var modePicker: some View {
        HStack(spacing: 0) {
            modeButton("Max")
            Divider().frame(height: 32).overlay(Color.white.opacity(0.08))
            modeButton("Th")
        }
        .frame(height: 78)
        .background(Color(red: 0.10, green: 0.10, blue: 0.11), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private func modeButton(_ title: String) -> some View {
        Button { selectedMode = title } label: {
            Text(title)
                .font(.system(size: 18, weight: .medium))
                .foregroundStyle(selectedMode == title ? Color(red: 1.0, green: 0.55, blue: 0.30) : .white.opacity(0.72))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .buttonStyle(.plain)
    }

    private var functionList: some View {
        VStack(spacing: 14) {
            ForEach(items) { item in
                FunctionRow(item: item, isEnabled: binding(for: item.id))
            }
        }
    }

    private func binding(for id: String) -> Binding<Bool> {
        switch id {
        case "pescoco": return $pescocoEnabled
        case "peito": return $peitoEnabled
        case "magica": return $magicaEnabled
        case "municao": return $municaoEnabled
        case "teste3d": return $teste3DEnabled
        default: return $testePersonagemEnabled
        }
    }

    private func placeholder(title: String, systemImage: String) -> some View {
        VStack(spacing: 16) {
            Image(systemName: systemImage)
                .font(.system(size: 42, weight: .medium))
                .foregroundStyle(Color(red: 1.0, green: 0.55, blue: 0.30))
            Text(title)
                .font(.system(size: 22, weight: .semibold))
            Text("Os arquivos importados estarão disponíveis nesta aba.")
                .font(.system(size: 15))
                .foregroundStyle(.white.opacity(0.55))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, minHeight: 320)
        .padding(24)
        .background(Color(red: 0.10, green: 0.10, blue: 0.11), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private var bottomNavigation: some View {
        HStack(spacing: 0) {
            bottomButton(.function, title: "Function", icon: "house.fill")
            bottomButton(.textures, title: "Texturas", icon: "person.crop.circle.fill")
            bottomButton(.config, title: "Config", icon: "shippingbox.fill")
        }
        .padding(8)
        .background(Color(red: 0.10, green: 0.10, blue: 0.11), in: Capsule())
    }

    private func bottomButton(_ tab: Tab, title: String, icon: String) -> some View {
        Button { selectedTab = tab } label: {
            VStack(spacing: 5) {
                Image(systemName: icon)
                    .font(.system(size: 22, weight: .medium))
                Text(title)
                    .font(.system(size: 13, weight: .medium))
            }
            .foregroundStyle(selectedTab == tab ? Color(red: 1.0, green: 0.55, blue: 0.30) : .white.opacity(0.58))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(selectedTab == tab ? Color.white.opacity(0.10) : .clear, in: Capsule())
        }
        .buttonStyle(.plain)
    }
}

private struct FunctionRow: View {
    let item: FunctionInterfaceView.FunctionItem
    @Binding var isEnabled: Bool

    var body: some View {
        HStack {
            Text(item.title)
                .font(.system(size: 18, weight: .regular))
                .foregroundStyle(.white)
            Spacer()
            Toggle(item.title, isOn: $isEnabled)
                .labelsHidden()
                .tint(Color(red: 1.0, green: 0.55, blue: 0.30))
                .accessibilityValue(isEnabled ? "Ativado" : "Desativado")
        }
        .padding(.horizontal, 32)
        .frame(height: 98)
        .background(Color(red: 0.10, green: 0.10, blue: 0.11), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}
